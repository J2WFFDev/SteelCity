
#!/usr/bin/env python3
# Discover AMG Commander START characteristic: subscribes to all notifiable UUIDs and logs hex on change.
import argparse, asyncio, time, json
from bleak import BleakScanner, BleakClient

def now_ms(): return time.monotonic() * 1000.0

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", default="hci0")
    args = ap.parse_args()

    async with BleakScanner(adapter=args.adapter) as scanner:
        print("[i] Scanning 6 s for AMG…")
        await asyncio.sleep(6.0)
        dev = None
        for d in await scanner.get_discovered_devices():
            if "amg" in (d.name or "").lower() or "commander" in (d.name or "").lower():
                dev = d; break
        if not dev:
            print("[!] AMG not found. Move closer or try again."); return

    print(f"[+] Connecting to {dev.address} {dev.name}")
    async with BleakClient(dev, adapter=args.adapter) as client:
        svcs = await client.get_services()
        notifs = [c for s in svcs for c in s.characteristics if "notify" in c.properties]
        print(f"[i] Subscribing to {len(notifs)} notifiable chars. Press START…")
        def cb(uuid):
            def _(_, data: bytearray):
                print("[notify]", uuid, len(data), data.hex())
            return _
        for ch in notifs:
            await client.start_notify(ch, cb(ch.uuid))
        await asyncio.sleep(20)
        for ch in notifs:
            await client.stop_notify(ch)

if __name__ == "__main__":
    asyncio.run(main())
