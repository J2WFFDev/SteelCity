
import asyncio, argparse
from bleak import BleakScanner, BleakClient

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", default="hci0")
    ap.add_argument("--mac")
    ap.add_argument("--name")
    args = ap.parse_args()

    dev = None
    async with BleakScanner(adapter=args.adapter) as scanner:
        print("[i] Scanning 6 s…")
        await asyncio.sleep(6.0)
        devices = await scanner.get_discovered_devices()
        for d in devices:
            n = (d.name or "").lower()
            if args.mac and d.address.lower() == args.mac.lower():
                dev = d; break
            if args.name and args.name.lower() in n:
                dev = d; break
        if not dev:
            print("[!] No matching device found. Listing top candidates:")
            for d in sorted(devices, key=lambda x: x.rssi or -999, reverse=True)[:10]:
                print("  ", d.address, d.rssi, d.name)
            return

    print(f"[+] Connecting to {dev.address} {dev.name} (RSSI={dev.rssi})")
    async with BleakClient(dev, adapter=args.adapter) as client:
        svcs = await client.get_services()
        for svc in svcs:
            print("SVC", svc.uuid)
            for ch in svc.characteristics:
                print("  CH", ch.uuid, ch.properties)
        # Subscribe to first notifiable for 5 s to preview payloads
        notif = None
        for c in [c for s in svcs for c in s.characteristics if "notify" in c.properties]:
            notif = c; break
        if notif:
            print("[i] Subscribing to", notif.uuid, "for 5 s")
            def cb(_, data: bytearray):
                print("[notify]", notif.uuid, len(data), data.hex())
            await client.start_notify(notif, cb)
            await asyncio.sleep(5.0)
            await client.stop_notify(notif)
        else:
            print("[i] No notifiable characteristics seen.")

if __name__ == "__main__":
    asyncio.run(main())
